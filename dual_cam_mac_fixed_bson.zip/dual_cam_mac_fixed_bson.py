import cv2
import time
import os
from bson import dumps
from datetime import datetime
import random

timestamp_root = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
SAVE_ROOT = os.path.join("captures", timestamp_root)

VIDEO_DIR = os.path.join(SAVE_ROOT, "VIDEO")
DAMP_DIR = os.path.join(SAVE_ROOT, "DAMP")

os.makedirs(VIDEO_DIR, exist_ok=True)
os.makedirs(DAMP_DIR, exist_ok=True)

def detect_cameras(max_index=4):
    cameras = []
    for i in range(max_index):
        cap = cv2.VideoCapture(i, cv2.CAP_AVFOUNDATION)
        if cap.read()[0]:
            print(f"✅ Камера {i} активна")
            cameras.append(i)
        else:
            print(f"❌ Камера {i} недоступна")
        cap.release()
    return cameras

available_cams = detect_cameras()
print(f"📸 Доступні камери: {available_cams}")

if not available_cams:
    print("🚫 Немає доступних камер. Завершення.")
    exit()

cams = []
ids = []
for i, cam_index in enumerate(available_cams):
    cap = cv2.VideoCapture(cam_index, cv2.CAP_AVFOUNDATION)
    cams.append(cap)
    ids.append(f"cam_{i:02}")

paths = {}
for cam_id in ids:
    vid_dir = os.path.join(VIDEO_DIR, cam_id)
    damp_dir = os.path.join(DAMP_DIR, cam_id)
    os.makedirs(vid_dir, exist_ok=True)
    os.makedirs(damp_dir, exist_ok=True)
    paths[cam_id] = {"video": vid_dir, "damp": damp_dir}

frame_id = 1001
print("▶ Тестовий запис на Mac (AVFoundation + bson.fix)")

try:
    while True:
        t0 = time.time()
        frames = []
        for cam in cams:
            ret, frame = cam.read()
            frames.append(frame if ret else None)
        t1 = time.time()

        att_data = {
            "roll": random.uniform(-0.05, 0.05),
            "pitch": random.uniform(-0.05, 0.05),
            "yaw": random.uniform(-3.14, 3.14)
        }

        for cam_id, frame in zip(ids, frames):
            if frame is None:
                continue

            filename = f"{cam_id}_{frame_id:013}.jpg"
            cv2.imwrite(os.path.join(paths[cam_id]["video"], filename), frame)

            doc = {
                "_id": filename,
                "type": "mac_test",
                "rf": None,
                "att": att_data,
                "timestamp": round(t0, 8),
                "frame_ts": round(t1, 8)
            }

            bson_path = os.path.join(paths[cam_id]["damp"], filename.replace(".jpg", ".bson"))
            with open(bson_path, "wb") as f:
                f.write(dumps(doc))

        print(f"💾 Кадр {frame_id} збережено")
        frame_id += 1

except KeyboardInterrupt:
    print("⏹ Тест завершено")

for cam in cams:
    cam.release()
